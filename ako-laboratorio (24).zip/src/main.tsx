import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Prevent annoying benign Vite websocket connection errors from displaying as uncaught rejections or errors
if (typeof window !== 'undefined') {
  const NativeWebSocket = window.WebSocket;

  class SafeWebSocket extends EventTarget {
    private _ws: any = null;
    private _url: string;
    public onopen: any = null;
    public onclose: any = null;
    public onerror: any = null;
    public onmessage: any = null;

    constructor(url: string, protocols?: string | string[]) {
      super();
      this._url = url;

      const isViteHmr = url.includes('vite') || url.includes('hmr') || url.includes('3000') || url.includes('localhost');

      if (isViteHmr) {
        console.warn('[HMR Silent Guard] Mocking benign HMR WebSocket connection for url:', url);
        // Dispatch close silently after a tiny delay so the client knows it's offline without erroring
        setTimeout(() => {
          const closeEvent = new CloseEvent('close', { code: 1006, reason: 'Benign HMR offline' });
          this.dispatchEvent(closeEvent);
          if (this.onclose) {
            try { this.onclose(closeEvent); } catch (e) {}
          }
        }, 50);
      } else if (NativeWebSocket) {
        try {
          this._ws = new NativeWebSocket(url, protocols);
          this._ws.onopen = (e: any) => {
            this.dispatchEvent(new Event('open'));
            if (this.onopen) this.onopen(e);
          };
          this._ws.onclose = (e: any) => {
            this.dispatchEvent(new CloseEvent('close', e));
            if (this.onclose) this.onclose(e);
          };
          this._ws.onerror = (e: any) => {
            this.dispatchEvent(new Event('error'));
            if (this.onerror) this.onerror(e);
          };
          this._ws.onmessage = (e: any) => {
            this.dispatchEvent(new MessageEvent('message', e));
            if (this.onmessage) this.onmessage(e);
          };
        } catch (err) {
          console.error('[HMR Silent Guard] Failed to instantiate native WebSocket:', err);
        }
      }
    }

    get readyState() {
      return this._ws ? this._ws.readyState : 3; // CLOSED
    }

    get url() {
      return this._url;
    }

    get protocol() {
      return this._ws ? this._ws.protocol : '';
    }

    get extensions() {
      return this._ws ? this._ws.extensions : '';
    }

    get bufferedAmount() {
      return this._ws ? this._ws.bufferedAmount : 0;
    }

    get binaryType() {
      return this._ws ? this._ws.binaryType : 'blob';
    }

    set binaryType(val) {
      if (this._ws) this._ws.binaryType = val;
    }

    send(data: any) {
      if (this._ws) this._ws.send(data);
    }

    close(code?: number, reason?: string) {
      if (this._ws) this._ws.close(code, reason);
    }
  }

  try {
    (window as any).WebSocket = SafeWebSocket;
  } catch (err) {
    try {
      Object.defineProperty(window, 'WebSocket', {
        value: SafeWebSocket,
        configurable: true,
        writable: true,
        enumerable: true
      });
    } catch (e) {
      console.warn('[HMR Silent Guard] Could not override window.WebSocket, relying on broad event capture:', e);
    }
  }

  // Broad-spectrum listener for unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const reasonStr = reason ? String(reason.message || reason.stack || reason) : '';
    
    // Detect any mention of WebSocket, close, connection, or Vite client
    const isBenignViteWs = 
      reasonStr.includes('WebSocket') || 
      reasonStr.includes('websocket') || 
      reasonStr.includes('vite') ||
      reasonStr.includes('closed without opened') ||
      (reason && typeof reason === 'object' && (
        reason.constructor?.name === 'CloseEvent' || 
        reason.constructor?.name === 'Event' ||
        reason.type === 'close' || 
        reason.code === 1006
      ));

    if (isBenignViteWs) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Prevented benign development websocket rejection:', reasonStr);
    }
  }, { capture: true });

  // Broad-spectrum listener for standard error events
  window.addEventListener('error', (event) => {
    const msg = event.message || '';
    const errorStr = event.error ? String(event.error.message || event.error.stack || event.error) : '';
    
    const isBenignViteWs = 
      msg.includes('WebSocket') || 
      msg.includes('websocket') || 
      msg.includes('vite') ||
      errorStr.includes('WebSocket') ||
      errorStr.includes('websocket') ||
      errorStr.includes('vite') ||
      errorStr.includes('closed without opened');

    if (isBenignViteWs) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Prevented benign development error event:', msg || errorStr);
    }
  }, { capture: true });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
