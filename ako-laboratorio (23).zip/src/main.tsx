import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Prevent annoying benign Vite websocket connection errors from displaying as uncaught rejections or errors
if (typeof window !== 'undefined') {
  // Broad-spectrum listener for unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const reasonStr = reason ? String(reason.message || reason.stack || reason) : '';
    
    // Detect any mention of WebSocket, close, connection, or Vite client
    const isBenignViteWs = 
      reasonStr.includes('WebSocket') || 
      reasonStr.includes('websocket') || 
      reasonStr.includes('vite') ||
      reasonStr.includes('closed without opened') ||
      (reason && typeof reason === 'object' && (
        reason.constructor?.name === 'CloseEvent' || 
        reason.constructor?.name === 'Event' ||
        reason.type === 'close' || 
        reason.code === 1006
      ));

    if (isBenignViteWs) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Prevented benign development websocket rejection:', reasonStr);
    }
  }, { capture: true });

  // Broad-spectrum listener for standard error events
  window.addEventListener('error', (event) => {
    const msg = event.message || '';
    const errorStr = event.error ? String(event.error.message || event.error.stack || event.error) : '';
    
    const isBenignViteWs = 
      msg.includes('WebSocket') || 
      msg.includes('websocket') || 
      msg.includes('vite') ||
      errorStr.includes('WebSocket') ||
      errorStr.includes('websocket') ||
      errorStr.includes('vite') ||
      errorStr.includes('closed without opened');

    if (isBenignViteWs) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Prevented benign development error event:', msg || errorStr);
    }
  }, { capture: true });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
