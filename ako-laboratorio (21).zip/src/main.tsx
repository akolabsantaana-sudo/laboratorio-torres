import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Prevent annoying benign Vite websocket connection errors from displaying as uncaught rejections or errors
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const reasonStr = reason ? String(reason.message || reason) : '';
    if (
      reasonStr.includes('WebSocket') || 
      reasonStr.includes('websocket') || 
      reasonStr.includes('vite') ||
      (reason?.stack && String(reason.stack).includes('vite'))
    ) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Ignored benign development websocket exception:', reasonStr);
    }
  });

  window.addEventListener('error', (event) => {
    const msg = event.message || '';
    if (
      msg.includes('WebSocket') || 
      msg.includes('websocket') || 
      msg.includes('vite')
    ) {
      event.preventDefault();
      event.stopPropagation();
      console.warn('[HMR Silent Guard] Ignored benign development error event:', msg);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
